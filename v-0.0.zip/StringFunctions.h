#ifndef STRINGFUNCTIONS_H
#define STRINGFUNCTIONS_H
using namespace std;

bool IsStringInteger(string a);
bool ContainString(string String, string Contain);

#endif // STRINGFUNCTIONS_H
