#ifndef BANDSTRUCTUREPROCESSING_H
#define BANDSTRUCTUREPROCESSING_H
using namespace std;
using namespace arma;

void BandStructureProcessing();
void FindBandGap(vec Kvec,mat Data);

#endif // BANDSTRUCTUREPROCESSING_H
