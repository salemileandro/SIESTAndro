#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <iomanip>
#include <vector>
#include"StringFunctions.h"
#include"GetInformationFromOutput.h"
#include"FileBrowser.h"
using namespace std;
using namespace arma;

void MullikenVisualization()
{
    cout << endl;
    cout << "---------------------------------------" << endl;
    cout << "---Mulliken Population Visualization---" << endl;
    cout << "---------------------------------------" << endl;
    cout << endl;


    string OutputFile,WorkDir;
    cout << "Select the output file of your SIESTA/TranSIESTA run."<< endl;
    SelectFile(OutputFile,"Select the output file of your SIESTA/TranSIESTA run.","fdf");
    GetDirectory(WorkDir,OutputFile);
    cout << "The selected file is :"<< endl;
    cout << OutputFile << endl;
    cout << endl;

    mat LatticeVectors, AtomicPositions;
    string Label;
    GetSystemLabel(OutputFile,Label);
    Label=WorkDir+Label;
    string XV=".XV";
    Label=Label+XV;
    ReadXVFile(LatticeVectors,AtomicPositions,Label);
    int NumberAtoms=AtomicPositions.n_rows;

    bool MullikenFound=false;


    string temp;
    string TargetSpinUp="mulliken: Spin UP";
    string TargetSpinDown="mulliken: Spin DOWN";
    string TargetEnd="mulliken: Qtot =";
    vector<string> SpinUp,SpinDown;
    SpinUp.clear();
    SpinDown.clear();
    bool A,B;
    A=false;
    B=false;
    ifstream ReadOutput(OutputFile.c_str());
    assert(ReadOutput.is_open());
    while(!ReadOutput.eof())
    {
        getline(ReadOutput,temp);



        if(ContainString(temp,TargetSpinUp))
            A=true;
        if(ContainString(temp,TargetSpinDown))
            B=true;
        if(A && !B)
            SpinUp.push_back(temp);
        if(!A && B)
            SpinDown.push_back(temp);
        if(A)
            MullikenFound=true;
        if(ContainString(temp,TargetEnd))
        {
            A=false;
            B=false;
        }

    }
    if(!MullikenFound)
    {
        cout << "!!! ERROR !!!" << endl;
        cout << "The output file does not contain the Mulliken population analysis..." << endl;
        cout << "........EXIT........" << endl;
        assert(MullikenFound);
    }

    vector<string> TempUp;
    TempUp.clear();
    for(int i=SpinUp.size()-1; i>-1; i--)
    {
        TempUp.push_back(SpinUp[i]);
        if(ContainString(SpinUp[i],TargetSpinUp))
            break;
    }
    SpinUp.clear();
    for(int i=TempUp.size()-1; i>-1; i--)
    {
        SpinUp.push_back(TempUp[i]);
    }
    TempUp.clear();

    vector<string> TempDown;
    TempDown.clear();
    for(int i=SpinDown.size()-1; i>-1; i--)
    {
        TempDown.push_back(SpinDown[i]);
        if(ContainString(SpinDown[i],TargetSpinDown))
            break;
    }
    SpinDown.clear();
    for(int i=TempDown.size()-1; i>-1; i--)
    {
        SpinDown.push_back(TempDown[i]);
    }
    TempDown.clear();

    string TextFileUp="TempUp.txt";
    string TextFileDown="TempDown.txt";
    TextFileUp=WorkDir+TextFileUp;
    TextFileDown=WorkDir+TextFileDown;

    ofstream WriteUp(TextFileUp.c_str());
    assert(WriteUp.is_open());
    ofstream WriteDown(TextFileDown.c_str());
    assert(WriteDown.is_open());
    for(int i=0; i<SpinUp.size(); i++)
    {
        WriteUp << SpinUp[i] << endl;
    }
    for(int i=0; i<SpinDown.size(); i++)
    {
        WriteDown << SpinDown[i] << endl;
    }
    WriteUp.close();
    WriteDown.close();

    ifstream ReadTempUp(TextFileUp.c_str());
    assert(ReadTempUp.is_open());
    string a;
    mat MullikenCharges(NumberAtoms,4);
    int compt=0;
    while(!ReadTempUp.eof())
    {
        ReadTempUp >> a ;
        if(IsStringInteger(a))
        {
            MullikenCharges(compt,0)=atof(a.c_str());
            ReadTempUp >> a ;
            MullikenCharges(compt,1)=atof(a.c_str());
            compt++;
        }
    }
    ReadTempUp.close();

    ifstream ReadTempDown(TextFileDown.c_str());
    assert(ReadTempDown.is_open());
    compt=0;
    while(!ReadTempDown.eof())
    {
        ReadTempDown >> a ;
        if(IsStringInteger(a))
        {
            ReadTempDown >> a ;
            MullikenCharges(compt,2)=atof(a.c_str());
            compt++;
        }
    }
    ReadTempDown.close();

    double TotUp=0;
    double TotDown=0;
    for(int i=0; i<MullikenCharges.n_rows; i++)
    {
        MullikenCharges(i,3)=MullikenCharges(i,1)-MullikenCharges(i,2);
        TotUp=TotUp+MullikenCharges(i,1);
        TotDown=TotDown+MullikenCharges(i,2);
    }
    mat MullikenChargesSorted(NumberAtoms,4);
    int j;
    for(int i=0; i<MullikenCharges.n_rows; i++)
    {
        j=((int)MullikenCharges(i,0))-1;
        MullikenChargesSorted(j,0)=MullikenCharges(i,0);
        MullikenChargesSorted(j,1)=MullikenCharges(i,1);
        MullikenChargesSorted(j,2)=MullikenCharges(i,2);
        MullikenChargesSorted(j,3)=MullikenCharges(i,3);

    }
    vec NormalizedRadii(NumberAtoms);
    double MAX=0;
    for(int i=0; i<NumberAtoms; i++)
    {
        if(MAX<abs(MullikenChargesSorted(i,3)))
        {
            MAX=abs(MullikenChargesSorted(i,3));
        }

    }
        for(int i=0; i<NumberAtoms; i++)
    {
        NormalizedRadii(i)=MullikenChargesSorted(i,3)/MAX;
        NormalizedRadii(i)=NormalizedRadii(i);
    }





    string dataUP="dataUP.gp";
    string dataDOWN="dataDOWN.gp";
    dataUP=WorkDir+dataUP;
    dataDOWN=WorkDir+dataDOWN;
    ofstream WriteDataUP (dataUP.c_str());
    assert(WriteDataUP.is_open());
    ofstream WriteDataDOWN (dataDOWN.c_str());
    assert(WriteDataDOWN.is_open());
    double Scale=1;
    for(int i=0; i<NumberAtoms; i++)
    {
        if(NormalizedRadii(i)>=0)
            WriteDataUP << AtomicPositions(i,2) << " " << AtomicPositions(i,1) << " "<< abs(NormalizedRadii(i))*Scale << endl;
        if(NormalizedRadii(i)<0)
            WriteDataDOWN << AtomicPositions(i,2) << " " << AtomicPositions(i,1) << " "<< abs(NormalizedRadii(i))*Scale << endl;

    }
    int SuperCellInZ;
    cout << "Supercell size in Z-direction : " ;
    cin >> SuperCellInZ;
    for(int S=0; S<SuperCellInZ; S++)
    {
        for(int i=0; i<NumberAtoms; i++)
        {
            if(NormalizedRadii(i)>=0)
                WriteDataUP << AtomicPositions(i,2)+S*LatticeVectors(2,2) << " " << AtomicPositions(i,1) << " "<< abs(NormalizedRadii(i))*Scale << endl;
            if(NormalizedRadii(i)<0)
                WriteDataDOWN << AtomicPositions(i,2)+S*LatticeVectors(2,2) << " " << AtomicPositions(i,1) << " "<< abs(NormalizedRadii(i))*Scale << endl;
        }
    }

    WriteDataUP.close();
    WriteDataDOWN.close();

    double Zmin,Zmax,Ymin,Ymax;
    Zmin=AtomicPositions(0,2);
    Zmax=AtomicPositions(0,2);
    Ymin=AtomicPositions(0,1);
    Ymax=AtomicPositions(0,1);
    for(int i=0; i<NumberAtoms; i++)
    {
        if(Zmax<AtomicPositions(i,2))
            Zmax=AtomicPositions(i,2);
        if(Zmin>AtomicPositions(i,2))
            Zmin=AtomicPositions(i,2);
        if(Ymax<AtomicPositions(i,1))
            Ymax=AtomicPositions(i,1);
        if(Ymin>AtomicPositions(i,1))
            Ymin=AtomicPositions(i,1);
    }
    double Zlength=Zmax-Zmin;
    double Ylength=Ymax-Ymin;
    Zmax=Zmax+(SuperCellInZ-1)*Zlength;
    if(Zmin<Ymin)
        Ymin=Zmin;
    else
        Zmin=Ymin;
    if(Zmax>Ymax)
        Ymax=Zmax;
    else
        Zmax=Ymax;



    string ScriptFile="ScriptMulliken.gp";
    ScriptFile=WorkDir+ScriptFile;
    ofstream WriteScript(ScriptFile.c_str());
    assert(WriteScript.is_open());
    WriteScript << "reset" << endl;
    WriteScript << "set notics" << endl;
    WriteScript << "set size square 1,1 " << endl;
    WriteScript << "set xrange["<<Zmin-3<<":"<<Zmax+3<<"]" << endl;
    WriteScript << "set yrange["<<Ymin-3<<":"<<Ymax+3<<"]" << endl;
    WriteScript << "plot'dataUP.gp' using 1:2:3 with circles fillstyle solid lt rgb \"#FF0000\" title'',";
    WriteScript << "'dataDOWN.gp' using 1:2:3 with circles fillstyle solid lt rgb \"#0000CD\" title'',";
    WriteScript << "'dataUP.gp' using 1:2 with points lt rgb \"#000000\" pointtype 7 ps 0.3 title'',";
    WriteScript << "'dataDOWN.gp' using 1:2 with points lt rgb \"#000000\" pointtype 7 ps 0.3 title''" << endl;
    WriteScript.close();

    cout << endl;
    cout << "Mulliken Summary :" << endl;
    cout << "   Qup = " << TotUp << "     Qdown = "<<TotDown << endl;
    cout << "      Qup-Qdown = Qtot = " << TotUp-TotDown << endl;



    string left="cd ";
    left=left+WorkDir;
    string right ="; gnuplot -p ";
    left=left+right;
    right="ScriptMulliken.gp";
    left=left+right;
    FILE *in;
    if (!(in = popen(left.c_str(),"r")))
    {
        return ;
    }


    return;


}

