#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <string.h>
#include <iomanip>
#include <vector>
#include <armadillo>
#include"StringFunctions.h"
#include"FileBrowser.h"
#include"LandauerButtikerFormalism.h"
using namespace std;
using namespace arma;

void LandauerButtikerFormalism()
{
    cout << endl;
    cout << "--------------------------------" << endl;
    cout << "---Landauer-Buttiker Formalism--" << endl;
    cout << "--------------------------------" << endl;
    cout << endl;

    string BandFile,WorkDir;
    SelectFile(BandFile,"Select the .bands file of your system","bands");
    GetDirectory(WorkDir,BandFile);
    double Ef,Kmin,Kmax,Emin,Emax;
    int Nbands,Nspin,Nkpoints;
    ifstream ReadBandFile(BandFile.c_str());
    assert(ReadBandFile.is_open());
    ReadBandFile >> Ef >> Kmin >> Kmax >> Emin >> Emax >> Nbands >> Nspin >> Nkpoints;

    vec Kpoints(Nkpoints);
    cube Data(Nkpoints,Nbands,Nspin);

    double temp;
    for(int i=0; i<Nkpoints; i++)
    {
        ReadBandFile >> temp;
        Kpoints(i)=temp;
        for(int j=0; j<Nbands; j++)
        {
            ReadBandFile >> temp;
            Data(i,j,0)=temp-Ef;
        }
        if(Nspin==2)
        {
            for(int j=0; j<Nbands; j++)
            {
                ReadBandFile >> temp;
                Data(i,j,1)=temp-Ef;
            }
        }
    }

    int Npath;
    ReadBandFile >> Npath;
    vec KPointsLoc(Npath);
    vector<string> Labels(Npath);
    for(int i=0; i<Npath; i++)
    {
        ReadBandFile >> KPointsLoc(i) >> Labels[i];
        if(Labels[i]=="'Gamma'")
            Labels[i]="'{/Symbol G}'";
    }

    double E_min,E_max;
    int Npoints;

    cout << "Emin =";
    cin >> E_min;
    cout << "Emax =";
    cin >> E_max;
    cout << "Npoints =";
    cin >> Npoints;
    vec E;
    vec EnergyPoints=linspace(E_min,E_max,Npoints);
    mat Transmission=zeros(Npoints,Nspin);
    for(int k=0; k<Nspin; k++)
    {
        for(int i=0; i<Nbands; i++)
        {
            ExtractEnergyVector(Data,i,k,E);
            for(int j=0; j<Npoints; j++)
            {
                if(max(E)<E_min || min(E)>E_max)
                {
                    break;
                }
                Transmission(j,k)=Transmission(j,k)+GetRoots(E,EnergyPoints(j));
            }
            if(min(E)>E_max) break;
            cout << Nbands << endl;
            cout << i<< endl;
        }
    }

    string FileTransmissionUp="/SIESTAndro_UP.TRANS";
    FileTransmissionUp=WorkDir+FileTransmissionUp;
    ofstream WriteTransUp(FileTransmissionUp.c_str());
    assert(WriteTransUp.is_open());
    for(int i=0; i<Npoints; i++)
    {
        WriteTransUp << EnergyPoints(i) << " " << Transmission(i,0) << " 0.0  0.0" << endl;
    }
    WriteTransUp.close();

    string FileTransmissionDown="/SIESTAndro_DN.TRANS";
    FileTransmissionDown=WorkDir+FileTransmissionDown;
    ofstream WriteTransDown(FileTransmissionDown.c_str());
    assert(WriteTransDown.is_open());
    for(int i=0; i<Npoints; i++)
    {
        if(Nspin==1)
            WriteTransDown << EnergyPoints(i) << " " << Transmission(i,0) << " 0.0  0.0" << endl;
        if(Nspin==2)
            WriteTransDown << EnergyPoints(i) << " " << Transmission(i,1) << " 0.0  0.0" << endl;
    }
    WriteTransDown.close();
}


void ExtractEnergyVector(cube Data,int colomn,int Nspin, vec &E)
{
    int Nrows=Data.n_rows;
    E.set_size(Nrows);
    for(int i=0; i<Nrows; i++)
    {
        E(i)=Data(i,colomn,Nspin);
    }
}

int GetRoots(vec E, double Ref)
{
    int a=0;
    for(int i=0; i<(E.n_elem-1); i++)
    {
        if(((E(i)-Ref)*(E(i+1)-Ref))<=0) a++;
    }
    return a;
}
