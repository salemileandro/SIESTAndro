#include<string>
#include <stdio.h>
#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <iomanip>
#include <vector>
#include"StringFunctions.h"
#include"GetInformationFromOutput.h"
#include"FileBrowser.h"
#include"GenerateSupercell.h"

using namespace std;
using namespace arma;

void TransiestaRunPreparation()
{
    cout << endl;
    cout << "--------------------------------" << endl;
    cout << "---TranSIESTA Run Preparation---" << endl;
    cout << "--------------------------------" << endl;
    cout << endl;

    int LoopBreaker=0;
    string LeftELCXV,RightELCXV,DeviceXV;
    char CharInput='p';
    SelectFile(LeftELCXV,"Select the .XV file for the LEFT electrode","XV");
    SelectFile(DeviceXV,"Select the .XV file for the DEVICE region","XV");
    LoopBreaker=0;
    while(CharInput!='Y' && CharInput!='N' && CharInput!='y' && CharInput!='n')
    {
        cout << "Is the right electrode the same as the left one ? (Y/N) " << endl;
        cin >> CharInput;
        if(CharInput=='Y' || CharInput=='y')
            RightELCXV=LeftELCXV;
        if(CharInput=='N' || CharInput=='n')
            SelectFile(RightELCXV,"Select the .XV file for the RIGHT electrode","XV");
        if(CharInput!='Y' && CharInput!='N' && CharInput!='y' && CharInput!='n')
            cout << "Please, write Y for yes or N for no ..." << endl;
        LoopBreaker++;
        assert(LoopBreaker<3);
    }

    mat LatVec_left,LatVec_right,LatVec_device;
    mat AtomPos_left,AtomPos_right,AtomPos_device;
    ReadXVFile(LatVec_left,AtomPos_left,LeftELCXV);
    ReadXVFile(LatVec_right,AtomPos_right,RightELCXV);
    ReadXVFile(LatVec_device,AtomPos_device,DeviceXV);

    // We first create the SIESTA run that
    // allows the relaxation of the device
    // region without the ELC
    int BufferLeft,BufferRight;
    cout << "How many layers of left electrode do you want as buffer between your device and the electrode ?" << endl;
    cin >> BufferLeft;
    cout << "How many layers of right electrode do you want as buffer between your device and the electrode ?" << endl;
    cin >> BufferRight;

    vec SupercellLeft(3),SupercellRight(3);
    SupercellLeft(0)=0;
    SupercellLeft(1)=0;
    SupercellLeft(2)=BufferLeft;
    SupercellRight(0)=0;
    SupercellRight(1)=0;
    SupercellRight(2)=BufferRight;

    CreateSuperCell(AtomPos_left,LatVec_left,SupercellLeft);
    CreateSuperCell(AtomPos_right,LatVec_right,SupercellRight);


    int Natom=AtomPos_left.n_rows+AtomPos_device.n_rows+AtomPos_right.n_rows;
    int Nleft=AtomPos_left.n_rows;
    int NleftContact=Nleft+AtomPos_device.n_rows;
    mat LatVec_SR(3,3),AtomPos_SR(Natom,4);
    LatVec_SR.zeros();
    LatVec_SR(2,2)=LatVec_left(2,2)+LatVec_device(2,2)+LatVec_right(2,2);

    for(int i=0; i<AtomPos_left.n_rows; i++)
    {
        for(int j=0; j<3; j++)
        {
            AtomPos_SR(i,j)=AtomPos_left(i,j);

        }
        AtomPos_SR(i,3)=AtomPos_left(i,3);
    }

    for(int i=0; i<AtomPos_device.n_rows; i++)
    {
        for(int j=0; j<2; j++)
        {
            AtomPos_SR(i+Nleft,j)=AtomPos_device(i,j);

        }
        AtomPos_SR(i+Nleft,2)=AtomPos_device(i,2)+LatVec_left(2,2);
        AtomPos_SR(i+Nleft,3)=AtomPos_device(i,3);
    }

    for(int i=0; i<AtomPos_right.n_rows; i++)
    {
        for(int j=0; j<2; j++)
        {
            AtomPos_SR(i+NleftContact,j)=AtomPos_right(i,j);

        }
        AtomPos_SR(i+NleftContact,2)=AtomPos_right(i,2)+LatVec_left(2,2)+LatVec_device(2,2);
        AtomPos_SR(i+NleftContact,3)=AtomPos_right(i,3);
    }
    rowvec Max=max(AtomPos_SR,0);
    rowvec Min=min(AtomPos_SR,0);
    LatVec_SR(0,0)=30+Max(0)-Min(0);
    LatVec_SR(1,1)=30+Max(1)-Min(1);

    string WorkDir,temp,Extension,slash;
    slash="/";
    Extension=".XV";
    cout << "Give the label of your system : " ;
    cin >> temp;
    SelectDirectory(WorkDir,"Select destination directory.");
    temp=slash+temp;
    temp=WorkDir+temp;
    temp=temp+Extension;
    WriteXVFile(AtomPos_SR,LatVec_SR,temp);
    temp="/StructureDefinition.fdf";
    temp=WorkDir+temp;
    GenerateFDFstructure(AtomPos_SR,LatVec_SR,temp);



    return;


}

