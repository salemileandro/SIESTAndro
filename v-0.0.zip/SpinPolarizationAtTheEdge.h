#ifndef SPINPOLARIZATIONATTHEEDGE_H
#define SPINPOLARIZATIONATTHEEDGE_H
using namespace std;

void SpinPolarizationAtTheEdge();

#endif // SPINPOLARIZATIONATTHEEDGE_H
