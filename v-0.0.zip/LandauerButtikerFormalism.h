#ifndef LANGAUERBUTTIKERFORMALIM_H
#define LANGAUERBUTTIKERFORMALIM_H
using namespace std;
using namespace arma;

void LandauerButtikerFormalism();
void ExtractEnergyVector(cube Data,int colomn,int Nspin, vec &E);
int GetRoots(vec E, double Ref);

#endif // LANGAUERBUTTIKERFORMALIM_H
