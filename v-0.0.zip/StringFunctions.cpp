#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <iomanip>
#include <vector>
using namespace std;


bool IsStringInteger(string a)
{
    int N=a.size();
    int q=0;
    for(int i=0; i<N; i++)
    {
        if(a[i]=='0') q++;
        if(a[i]=='1') q++;
        if(a[i]=='2') q++;
        if(a[i]=='3') q++;
        if(a[i]=='4') q++;
        if(a[i]=='5') q++;
        if(a[i]=='6') q++;
        if(a[i]=='7') q++;
        if(a[i]=='8') q++;
        if(a[i]=='9') q++;
    }
    if(q==N) return true;
    else return false;
}

bool ContainString(string String, string Contain)
{
    int Ns,Nc;
    Ns=String.size();
    Nc=Contain.size();

    size_t found = String.find(Contain);
    if (found!=std::string::npos)
    {
        return true;
    }
    else
    {
        return false;
    }
}


