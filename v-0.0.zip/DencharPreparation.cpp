#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <string.h>
#include <iomanip>
#include <vector>
#include <armadillo>
#include"StringFunctions.h"
#include"FileBrowser.h"
#include"DencharPreparation.h"
using namespace std;
using namespace arma;

void DencharPreparation()
{
    cout << endl;
    cout << "-------------------------" << endl;
    cout << "---Denchar Preparation---" << endl;
    cout << "-------------------------" << endl;
    cout << endl;

    string BandFile,WorkDir;
    SelectFile(BandFile,"Select the .bands file of your system","bands");
    GetDirectory(WorkDir,BandFile);
    double Ef,Kmin,Kmax,Emin,Emax;
    int Nbands,Nspin,Nkpoints;
    ifstream ReadBandFile(BandFile.c_str());
    assert(ReadBandFile.is_open());
    ReadBandFile >> Ef >> Kmin >> Kmax >> Emin >> Emax >> Nbands >> Nspin >> Nkpoints;

    vec Kpoints(Nkpoints);
    cube Data(Nkpoints,Nbands,Nspin);

    double temp;
    for(int i=0; i<Nkpoints; i++)
    {
        ReadBandFile >> temp;
        Kpoints(i)=temp;
        for(int j=0; j<Nbands; j++)
        {
            ReadBandFile >> temp;
            Data(i,j,0)=temp-Ef;
        }
        if(Nspin==2)
        {
            for(int j=0; j<Nbands; j++)
            {
                ReadBandFile >> temp;
                Data(i,j,1)=temp-Ef;
            }
        }
    }

    double WF_Emin,WF_Emax;
    cout << "Give the energy range you want to cover (eV)..." << endl;
    cout << "Emin = ";
    cin >> WF_Emin;
    cout << "Emax = ";
    cin >> WF_Emax;
    string BandIndex;
    string Bandtemp;
    string space=" ";
    bool IsBandWritten=false;

    for(int i=0; i<Nbands; i++)
    {
        IsBandWritten=false;
        for(int j=0; j<Nkpoints; j++)
        {
            if(Data(j,i,0) <= WF_Emax  && Data(j,i,0) >= WF_Emin && !IsBandWritten)
            {
                Bandtemp=to_string(i+1);
                Bandtemp+=space;
                BandIndex+=Bandtemp;
                IsBandWritten=true;
            }
        }
    }
    cout <<" For spin 1 : " << BandIndex << endl;
    BandIndex="";
    Bandtemp="";

    if(Nspin==2)
    {
        for(int i=0; i<Nbands; i++)
        {
            IsBandWritten=false;
            for(int j=0; j<Nkpoints; j++)
            {
                if(Data(j,i,1) <= WF_Emax  && Data(j,i,1) >= WF_Emin && !IsBandWritten)
                {
                Bandtemp=to_string(i+1);
                Bandtemp+=space;
                BandIndex+=Bandtemp;
                IsBandWritten=true;
                }
            }
        }
    cout <<" For spin 2 : " << BandIndex << endl;
    BandIndex="";
    }
}

