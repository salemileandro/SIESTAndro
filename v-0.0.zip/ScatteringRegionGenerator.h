#ifndef SCATTERINGREGIONGENERATOR_H
#define SCATTERINGREGIONGENERATOR_H
using namespace std;

void ScatteringRegionGenerator();

#endif // SCATTERINGREGIONGENERATOR_H


