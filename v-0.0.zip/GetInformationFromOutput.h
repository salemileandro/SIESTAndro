#ifndef GETINFORMATIONFROMOUTPUT_H
#define GETINFORMATIONFROMOUTPUT_H
using namespace std;
using namespace arma;

void GetSystemLabel(string OutputFile, string &SystemLabel);
double GetMeshCutOff(string OutputFile);
void GetKGrid(string OutputFile, vec &KGrid);
void GetBondLength(mat AtomicCoordinates,mat BondInput,vec &BondLength);
int GetNumberAtoms(string OutputFile);
void ReadXVFile(mat &LatticeVectors, mat &AtomicPositions, string FileName);
void WriteXVFile(mat AtomicPositions, mat LatticeVectors ,string OutputFile);
void GenerateFDFstructure(mat AtomicPositions,mat LatticeVectors, string FDFfile);



#endif // GETINFORMATIONFROMOUTPUT_H
