#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <iomanip>
#include <vector>
#include"StringFunctions.h"
#include"GetInformationFromOutput.h"
#include"FileBrowser.h"

using namespace std;
using namespace arma;

void ScatteringRegionGenerator()
{
    cout << endl;
    cout << "---------------------------------" << endl;
    cout << "---Scattering Region Generator---" << endl;
    cout << "---------------------------------" << endl;
    cout << endl;

    int LoopBreaker=0;
    string LeftELCXV,RightELCXV,ContactXV;
    char CharInput='p';
    SelectFile(LeftELCXV,"Select the .XV file for the LEFT electrode","XV");
    SelectFile(ContactXV,"Select the .XV file for the CONTACT region","XV");
    LoopBreaker=0;
    while(CharInput!='Y' && CharInput!='N' && CharInput!='y' && CharInput!='n')
    {
        cout << "Is the right electrode the same as the left one ? (Y/N) " << endl;
        cin >> CharInput;
        if(CharInput=='Y' || CharInput=='y')
            RightELCXV=LeftELCXV;
        if(CharInput=='N' || CharInput=='n')
            SelectFile(RightELCXV,"Select the .XV file for the RIGHT electrode","XV");
        if(CharInput!='Y' && CharInput!='N' && CharInput!='y' && CharInput!='n')
            cout << "Please, write Y for yes or N for no ..." << endl;
        LoopBreaker++;
        assert(LoopBreaker<3);
    }

    mat LatVec_left,LatVec_right,LatVec_contact;
    mat AtomPos_left,AtomPos_right,AtomPos_contact;
    ReadXVFile(LatVec_left,AtomPos_left,LeftELCXV);
    ReadXVFile(LatVec_right,AtomPos_right,RightELCXV);
    ReadXVFile(LatVec_contact,AtomPos_contact,ContactXV);

    int Natom=AtomPos_left.n_rows+AtomPos_contact.n_rows+AtomPos_right.n_rows;
    int Nleft=AtomPos_left.n_rows;
    int Nright=AtomPos_right.n_rows;
    int NleftContact=Nleft+AtomPos_contact.n_rows;
    mat LatVec_SR(3,3),AtomPos_SR(Natom,4);
    LatVec_SR.zeros();
    LatVec_SR(2,2)=LatVec_left(2,2)+LatVec_contact(2,2)+LatVec_right(2,2);

    for(int i=0; i<AtomPos_left.n_rows; i++)
    {
        for(int j=0; j<3; j++)
        {
            AtomPos_SR(i,j)=AtomPos_left(i,j);

        }
        AtomPos_SR(i,3)=AtomPos_left(i,3);
    }

    for(int i=0; i<AtomPos_contact.n_rows; i++)
    {
        for(int j=0; j<2; j++)
        {
            AtomPos_SR(i+Nleft,j)=AtomPos_contact(i,j);

        }
        AtomPos_SR(i+Nleft,2)=AtomPos_contact(i,2)+LatVec_left(2,2);
        AtomPos_SR(i+Nleft,3)=AtomPos_contact(i,3);
    }

    for(int i=0; i<AtomPos_right.n_rows; i++)
    {
        for(int j=0; j<2; j++)
        {
            AtomPos_SR(i+NleftContact,j)=AtomPos_right(i,j);

        }
        AtomPos_SR(i+NleftContact,2)=AtomPos_right(i,2)+LatVec_left(2,2)+LatVec_contact(2,2);
        AtomPos_SR(i+NleftContact,3)=AtomPos_right(i,3);
    }
    rowvec Max=max(AtomPos_SR,0);
    rowvec Min=min(AtomPos_SR,0);
    LatVec_SR(0,0)=30+Max(0)-Min(0);
    LatVec_SR(1,1)=30+Max(1)-Min(1);

    string WorkDir,temp,Extension,slash;
    slash="/";
    Extension=".XV";
    cout << "Give the label of your system : " ;
    cin >> temp;
    SelectDirectory(WorkDir,"Select destination directory.");
    temp=slash+temp;
    temp=WorkDir+temp;
    temp=temp+Extension;
    WriteXVFile(AtomPos_SR,LatVec_SR,temp);
    temp="/StructureDefinition.fdf";
    temp=WorkDir+temp;
    GenerateFDFstructure(AtomPos_SR,LatVec_SR,temp);
    temp="/GeometryConstraints.txt";
    temp=WorkDir+temp;
    ofstream WriteGeoCons(temp.c_str());
    assert(WriteGeoCons.is_open());
    WriteGeoCons << "%block GeometryConstraints" << endl;
    WriteGeoCons << "position from 1 to " << Nleft << endl;
    WriteGeoCons << "%endblock GeometryConstraints" << endl;
    WriteGeoCons << "%block GeometryConstraints" << endl;
    WriteGeoCons << "position from -1 to " << Nright << endl;
    WriteGeoCons << "%endblock GeometryConstraints" << endl;
    WriteGeoCons << "%block GeometryConstraints" << endl;
    WriteGeoCons << "stress 1 2 4 5 6" << endl;
    WriteGeoCons << "%endblock GeometryConstraints" << endl;
    WriteGeoCons.close();

    return;

}

