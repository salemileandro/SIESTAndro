
#ifndef GENERATESUPERCELL_H
#define GENERATESUPERCELL_H
using namespace std;
using namespace arma;

void GenerateSupercell();
void CreateSuperCell(mat &AtomicCoordinates,mat &LatticeVectors, vec Periodicity);
void TranslateAllPositions(mat &Positions,vec Translator,int Times);


#endif // GENERATESUPERCELL_H
