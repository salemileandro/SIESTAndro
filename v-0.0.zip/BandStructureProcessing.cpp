#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <string.h>
#include <iomanip>
#include <vector>
#include <armadillo>
#include"StringFunctions.h"
#include"FileBrowser.h"
#include"BandStructureProcessing.h"
using namespace std;
using namespace arma;

void BandStructureProcessing()
{
    cout << endl;
    cout << "------------------------------" << endl;
    cout << "---Band Structure Processing--" << endl;
    cout << "------------------------------" << endl;
    cout << endl;

    string BandFile,WorkDir;
    SelectFile(BandFile,"Select the .bands file of your system","bands");
    GetDirectory(WorkDir,BandFile);
    double Ef,Kmin,Kmax,Emin,Emax;
    int Nbands,Nspin,Nkpoints;
    ifstream ReadBandFile(BandFile.c_str());
    assert(ReadBandFile.is_open());
    ReadBandFile >> Ef >> Kmin >> Kmax >> Emin >> Emax >> Nbands >> Nspin >> Nkpoints;

    vec Kpoints(Nkpoints);
    cube Data(Nkpoints,Nbands,Nspin);

    double temp;
    for(int i=0; i<Nkpoints; i++)
    {
        ReadBandFile >> temp;
        Kpoints(i)=temp;
        for(int j=0; j<Nbands; j++)
        {
            ReadBandFile >> temp;
            Data(i,j,0)=temp-Ef;
        }
        if(Nspin==2)
        {
            for(int j=0; j<Nbands; j++)
            {
                ReadBandFile >> temp;
                Data(i,j,1)=temp-Ef;
            }
        }
    }

    int Npath;
    ReadBandFile >> Npath;
    vec KPointsLoc(Npath);
    vector<string> Labels(Npath);
    for(int i=0; i<Npath; i++)
    {
        ReadBandFile >> KPointsLoc(i) >> Labels[i];
        if(Labels[i]=="'Gamma'")
            Labels[i]="'{/Symbol G}'";
    }

    string BandSpin1="/BandSpin1.gp";
    BandSpin1=WorkDir+BandSpin1;
    ofstream WriteSpin1(BandSpin1.c_str());
    assert(WriteSpin1.is_open());
    for(int i=0; i<Nbands; i++)
    {
        for(int j=0; j<Nkpoints; j++)
        {
            WriteSpin1 << Kpoints(j) << " " << Data(j,i,0) << endl;
        }
        WriteSpin1 << endl;
        WriteSpin1 << endl;
        WriteSpin1 << endl;
    }
    WriteSpin1.close();

    if(Nspin==2)
    {
        string BandSpin2="/BandSpin2.gp";
        BandSpin2=WorkDir+BandSpin2;
        ofstream WriteSpin2(BandSpin2.c_str());
        assert(WriteSpin2.is_open());
        for(int i=0; i<Nbands; i++)
        {
            for(int j=0; j<Nkpoints; j++)
            {
                WriteSpin2 << Kpoints(j) << " " << Data(j,i,1) << endl;
            }
            WriteSpin2 << endl;
            WriteSpin2 << endl;
            WriteSpin2 << endl;
        }
        WriteSpin2.close();
    }

    string Script="/ScriptBand.gp";
    Script=WorkDir+Script;
    ofstream WriteScript(Script.c_str());
    assert(WriteScript.is_open());
    WriteScript << "reset" << endl;
    WriteScript << "set terminal postscript eps enhanced color font'Times,20' linewidth 2"<<endl;
    WriteScript << "set output 'BANDSTRUCTURE.eps'" << endl;
    WriteScript << "set termopt enhanced" << endl;
    WriteScript << "set termoption dash" << endl;
    WriteScript << "### Definition of variables" << endl;
    WriteScript << "set style line 99 dashtype 2 lt rgb \"#696969\" lw 1  	# Grey Dashed Line for Grid" << endl;
    WriteScript << "set style line 1 lt rgb \"#FF0000\" lw 3			# Red Line for Plot" << endl;
    WriteScript << "set style line 2 lt rgb \"#0000CD\" lw 3			# Blue Line for Plot" << endl;
    WriteScript << "set style line 3 dashtype 2 lt rgb \"#000000\" lw 1	# Black Line for Plot" << endl;
    WriteScript << "set grid ls 99" << endl;
    WriteScript << "set yrange [-0.5:0.5]" << endl;
    WriteScript << "set xtics  (";
    for(int i=0; i<Npath; i++)
    {
        WriteScript << Labels[i] << "  " << KPointsLoc(i);
        if(i!=(Npath-1))
        {
            WriteScript << ", " ;
        }
    }
    WriteScript << ") font',25' offset 0,-1" << endl;
    WriteScript << "set ytics -10,0.1,10 font',25 offset -1,0" << endl;
    WriteScript << "#set title 'Band Structure' font',40' offset 0,3" << endl;
    WriteScript << "set xlabel 'Reciprocal Space' font',40' offset 0,-0.5" << endl;
    WriteScript << "set ylabel 'Energy-E_{F} [eV]' font',40' offset -7,0" << endl;
    WriteScript << "set tmargin at screen 0.95" << endl;
    WriteScript << "set bmargin at screen 0.12" << endl;
    WriteScript << "set rmargin at screen 0.95" << endl;
    WriteScript << "set lmargin at screen 0.15" << endl;
    WriteScript << "plot'BandSpin1.gp' using 1:2 with lines ls 1" ;
    if(Nspin==1)
    {
        WriteScript << " title''," ;
    }
    else
    {
        WriteScript << " title'','BandSpin2.gp' using 1:2 with lines ls 2 title''," ;
    }
    WriteScript << "0 ls 3 title ''" << endl;

    WriteScript.close();

    string Command,CD;
    CD="cd ";
    CD=CD+WorkDir;
    Command=" ; gnuplot -p ScriptBand.gp";
    Command=CD+Command;
    FILE *in;
    char buff[512];
    if(!(in = popen(Command.c_str(), "r"))){
            return ;
        }
    while(fgets(buff, sizeof(buff), in)!=NULL){
            cout << buff;
    }

    cout << "Computation of the BandGap." << endl;
    cout << "Numerically, there is always a band gap ... TAKE CARE !" << endl;
    cout << endl;

    cout << "---->For SPIN 1 :" << endl;
    FindBandGap(Kpoints,Data.slice(0));
    cout << endl;
    if(Nspin==2)
    {
        cout << "---->For SPIN 2 :" << endl;
        FindBandGap(Kpoints,Data.slice(1));
        cout << endl;
    }
}


void FindBandGap(vec Kvec,mat Data)
{
    int Nbands,Nspin,Nkpoints;
    Nbands=Data.n_cols;
    Nkpoints=Data.n_rows;

    vec CondMax(2),ValMin(2);
    CondMax(1)=Data(0,0);
    ValMin(1)=Data(0,Nbands-1);
    int index1,index2;
    int Band1,Band2;
    for(int i=0; i<Nkpoints; i++)
    {
        for(int j=0; j<Nbands; j++)
        {
            if(Data(i,j)<=0 && CondMax(1)<=Data(i,j))
            {
                CondMax(1)=Data(i,j);
                CondMax(0)=Kvec(i);
            }
            if(Data(i,j)>=0 && ValMin(1)>=Data(i,j))
            {
                ValMin(1)=Data(i,j);
                ValMin(0)=Kvec(i);
            }
        }
    }


    cout << "Top of conduction band : k = "<<CondMax(0) <<", E = " << CondMax(1)*1000 << " meV" << endl;
    cout << "Bottom of the valence band : k = "<<ValMin(0) <<", E = " << ValMin(1)*1000 << " meV" << endl;
    cout << "BandGap Eg = " << (ValMin(1)-CondMax(1))*1000 << " meV (";
    if(CondMax(0)==ValMin(0))
    {
        cout <<"DIRECT)" << endl;
    }
    else
    {
        cout <<"INDIRECT)" << endl;

    }






}

