#ifndef DENCHARPREPARATION_H
#define DENCHARPREPARATION_H
using namespace std;
using namespace arma;

void DencharPreparation();

#endif // DENCHARPREPARATION_H
