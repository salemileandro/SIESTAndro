#include<string>
#include <stdio.h>
#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <iomanip>
#include <vector>
#include"StringFunctions.h"
#include"GetInformationFromOutput.h"
#include"FileBrowser.h"
#include"GenerateSupercell.h"

using namespace std;
using namespace arma;

void GenerateSupercell()
{
    cout << endl;
    cout << "-----------------------" << endl;
    cout << "---Generate Supercell--" << endl;
    cout << "-----------------------" << endl;
    cout << endl;


    string UnitCellXVFile;
    SelectFile(UnitCellXVFile,"Select the .XV file of the unit cell","XV");
    mat LatticeVectors, AtomicPositions;
    ReadXVFile(LatticeVectors,AtomicPositions,UnitCellXVFile);

    vec SupercellSize(3);
    cout << "Enter the size of the super cell in ..." << endl;
    cout << "the x direction: ";
    cin >> SupercellSize(0);
    cout << "the y direction: ";
    cin >> SupercellSize(1);
    cout << "the z direction: ";
    cin >> SupercellSize(2);

    CreateSuperCell(AtomicPositions,LatticeVectors,SupercellSize);
    string DirectoryName,temp;
    temp="/SUPERCELL.XV";
    SelectDirectory(DirectoryName,"Select destination directory.");
    temp=DirectoryName+temp;
    WriteXVFile(AtomicPositions,LatticeVectors,temp);
    temp="/StructureDefinition.fdf";
    temp=DirectoryName+temp;
    GenerateFDFstructure(AtomicPositions,LatticeVectors,temp);

}


void CreateSuperCell(mat &AtomicCoordinates,mat &LatticeVectors, vec Periodicity)
{
    // We generate the translators in the three directions.
    // The last component is set to 0. This is to ensure that
    // we keep the atomic label for SIESTA input file.
    vec X(4),Y(4),Z(4);
    for(int i=0; i<3; i++)
    {
        X(i)=LatticeVectors(0,i);
        Y(i)=LatticeVectors(1,i);
        Z(i)=LatticeVectors(2,i);
    }
    X(3)=0;
    Y(3)=0;
    Z(3)=0;

    // Translation of the cell in the three directions
    TranslateAllPositions(AtomicCoordinates,X,Periodicity(0));
    TranslateAllPositions(AtomicCoordinates,Y,Periodicity(1));
    TranslateAllPositions(AtomicCoordinates,Z,Periodicity(2));
    for(int i=0; i<3; i++)
    {
        for(int j=0; j<3;j++)
        {
            LatticeVectors(i,j)=LatticeVectors(i,j)*Periodicity(i);
        }
    }
    return;
}

void TranslateAllPositions(mat &Positions,vec Translator,int Times)
{

    int Nrow,Ncol;
    Nrow=Positions.n_rows;
    Ncol=Positions.n_cols;

    mat PositionStock(Nrow,Ncol);
    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<Ncol; j++)
        {
            PositionStock(i,j)=Positions(i,j);
        }
    }


    Positions.zeros(Nrow*Times,Ncol);
    for(int i=0; i<Nrow; i++)
    {
        for(int j=0; j<Ncol; j++)
        {
            Positions(i,j)=PositionStock(i,j);
        }
    }


    for(int p=1; p<Times ; p++)
    {
        for(int i=0; i<Nrow; i++)
        {
            for(int j=0; j<Ncol; j++)
            {
                Positions(i+p*Nrow,j)=PositionStock(i,j)+p*Translator(j);
            }
        }
    }

}


