#include<string>
#include <stdio.h>
#include <fstream>
#include <stdlib.h>
#include <armadillo>
#include <iomanip>
using namespace std;


void SelectDirectory(string &DirectoryName, string message)
{
    string left="zenity  --title=\"";
    string right ="\" --file-selection --directory";
    left=left+message;
    left=left+right;
    FILE *in;
    if (!(in = popen(left.c_str(),"r")))
    {
        return ;
    }

    char buff[512];
    string selectFile = "";
    while (fgets(buff, sizeof(buff), in) != NULL)
    {
        selectFile += buff;
    }
    pclose(in);

    //remove the "\n"
    selectFile.erase(std::remove(selectFile.begin(), selectFile.end(), '\n'),
    selectFile.end());

    DirectoryName=selectFile;
    return;
}

void SelectFile(string &Filename, string message,string FileType)
{
    cout << message << endl;
    string left="zenity  --title=\"";
    string temp="\"\"";
    temp=FileType+temp;
    string right ="\" --file-selection --file-filter=\"\"*.";
    right=right+temp;
    left=left+message;
    left=left+right;
    FILE *in;
    if (!(in = popen(left.c_str(),"r")))
    {
        return ;
    }

    char buff[512];
    string selectFile = "";
    while (fgets(buff, sizeof(buff), in) != NULL)
    {
        selectFile += buff;
    }
    pclose(in);

    //remove the "\n"
    selectFile.erase(std::remove(selectFile.begin(), selectFile.end(), '\n'),
    selectFile.end());

    Filename=selectFile;
    cout << "File selected : " << Filename << endl;
    return;
}

void GetDirectory(string &Directory, string File)
{
    int N=File.size();
    for(int i=N-1; i>-1; i--)
    {
        if(File[i]!='/')
        {
            File.erase(i);
        }
        else
        {
            break;
        }
    }
    Directory=File;

    return;
}
