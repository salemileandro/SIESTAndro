#include <cassert>
#include <iostream>
#include <ctime>
#include <fstream>
#include <cmath>
#include <vector>
#include <stdlib.h>
#include <armadillo>
#include <math.h>
#include <string>
#include <fcntl.h>
#include <sstream>
#include <iomanip>
#include <vector>
#include"FileBrowser.h"
#include"MullikenVisualization.h"
#include"StringFunctions.h"
#include"GetInformationFromOutput.h"
#include"ScatteringRegionGenerator.h"
#include"BandStructureProcessing.h"
#include"TransiestaRunPreparation.h"
#include"GenerateSupercell.h"
#include"SpinPolarizationAtTheEdge.h"
#include"DencharPreparation.h"
#include"LandauerButtikerFormalism.h"
#include"CurrentFromTransmission.h"


using namespace std;
using namespace arma;

void ReadTransFile(mat &Data, string File);

#define PI 3.14159265

int main()
{
    // Get the date/time and write it in the log file
    time_t now = time(0);
    tm* localtm = localtime(&now);
    cout << "******************** "<< endl;
    cout << "**** SIESTAndro **** "<< endl;
    cout << "******************** "<< endl;
    cout << "Program written by Leandro Salemi" << endl;
    cout << "For any question : salemileandro@gmail.com" << endl;
    cout << "----------------------------------------------" << endl;
    cout << "Start of run : " << asctime(localtm) << endl;

    int Choice;
    bool Again=false;
    do
    {
        Again=false;
        cout << "Choose your utility ..." << endl;
        cout << "1° Generate Supercell" << endl;
        cout << "2° Scattering Region Generator" << endl;
        cout << "3° Band Structure Processing" << endl;
        cout << "4° Magnetoresistance Computation" << endl;
        cout << "5° Modify Ribbon" << endl;
        cout << "6° Generate StructDef from .XV" << endl;
        cout << "7° DOS Processing" << endl;
        cout << "8° Stick together" << endl;
        cout << "9° Mulliken Population Visualization" << endl;
        cout << "10° TranSIESTA Run Preparation" << endl;
        cout << "11° Spin Polarization at the Edge" << endl;
        cout << "12° Denchar Preparation" << endl;
        cout << "13° Landauer-Buttiker Formalism" << endl;
        cout << "14° Current from Transmission" << endl;
        cout << endl;
        cout << "Your choice : ";
        cin >> Choice;


        switch(Choice)
        {
        case 1:
            {
                GenerateSupercell();
                break;
            }
        case 2:
            {
                ScatteringRegionGenerator();
                break;
            }
        case 3:
            {
                BandStructureProcessing();
                break;
            }
        case 4:
            {
                cout << endl;
                cout << "----------------------------------" << endl;
                cout << "---Magnetoresistance Computation--" << endl;
                cout << "----------------------------------" << endl;
                cout << endl;

                mat FMdown,FMup,AFMdown,AFMup;
                string TransFile;

                cout << "Select the .TRANS file of FM system for SPIN DOWN channel." << endl;
                SelectFile(TransFile,"Select the .TRANS file of FM system for SPIN DOWN channel.","TRANS");
                ReadTransFile(FMdown,TransFile);

                cout << "Select the .TRANS file of FM system for SPIN UP channel." << endl;
                SelectFile(TransFile,"Select the .TRANS file of FM system for SPIN UP channel.","TRANS");
                ReadTransFile(FMup,TransFile);

                cout << "Select the .TRANS file of AFM system for SPIN DOWN channel." << endl;
                SelectFile(TransFile,"Select the .TRANS file of AFM system for SPIN DOWN channel.","TRANS");
                ReadTransFile(AFMdown,TransFile);

                cout << "Select the .TRANS file of AFM system for SPIN UP channel." << endl;
                SelectFile(TransFile,"Select the .TRANS file of AFM system for SPIN UP channel.","TRANS");
                ReadTransFile(AFMup,TransFile);

                int N=FMdown.n_rows;
                mat MagnRes(N,2);
                double Tp,Tap;
                ofstream Write("MAGNETORESISTANCE.gp");
                assert(Write.is_open());
                for(int i=0; i<N; i++)
                {
                    MagnRes(i,0)=FMdown(i,0);
                    Tp=FMdown(i,1)+FMup(i,1);
                    Tap=AFMdown(i,1)+AFMup(i,1);
                    MagnRes(i,1)=(Tp-Tap)/(Tp+Tap);

                    Write << MagnRes(i,0) << " " << MagnRes(i,1) << endl;
                }
                Write.close();

//    FILE *in;
//    char buff[512];
//    if(!(in = popen("gnuplot -persist >> load 'script.gp'", "r"))){
//            return 1;
//    }
//    while(fgets(buff, sizeof(buff), in)!=NULL){
//            cout << buff;
//    }
//
//    cout << " IT'S WORKING :3" << endl;

           break;
            }
        case 5:
            {
                cout << endl;
                cout << "-------------------" << endl;
                cout << "---Modify Ribbon---" << endl;
                cout << "-------------------" << endl;
                cout << endl;

                string RibbonPerfect;
                cout << "Select the .XV file of the perfect ribbon"<< endl;

                break;
            }
        case 6:
            {
                cout << endl;
                cout << "---------------------------------" << endl;
                cout << "---Generate StructDef from .XV---" << endl;
                cout << "---------------------------------" << endl;
                cout << endl;

                mat LatticeVectors,AtomicPositions;
                string XVfile;
                cout << "Select the .XV file"<< endl;
                SelectFile(XVfile,"Select the .XV file","XV");
                ReadXVFile(LatticeVectors,AtomicPositions,XVfile);

                string DirectoryName,temp;
                GetDirectory(DirectoryName,XVfile);
                temp="/StructureDefinition.fdf";
                temp=DirectoryName+temp;
                GenerateFDFstructure(AtomicPositions,LatticeVectors,temp);

                break;
            }
        case 7:
            {
                cout << endl;
                cout << "------------------------------" << endl;
                cout << "--------DOS Processing--------" << endl;
                cout << "------------------------------" << endl;
                cout << endl;

                string EIGFile,WorkDir,temp,space;
                space=" ";
                cout << "Select the .EIG file" << endl;
                SelectFile(EIGFile,"Select the .EIG file","EIG");
                GetDirectory(WorkDir,EIGFile);

                string EIG2DOS,cmd;
                EIG2DOS="/home/leandro/Documents/SIESTA/siesta-4.1-b1/Util/Eig2DOS/Eig2DOS -f -s ";

                cout << "Enter the broadening factor (eV) : ";
                cin >> temp;
                EIG2DOS=EIG2DOS+temp;

                temp=" -n ";
                EIG2DOS=EIG2DOS+temp;
                cout << "Enter the number of eigenvalues (large!) : ";
                cin >> temp;
                EIG2DOS=EIG2DOS+temp;
                int N=stoi(temp);

                temp=" -m ";
                EIG2DOS=EIG2DOS+temp;
                cout << "Enter Emin (eV) : ";
                cin >> temp;
                EIG2DOS=EIG2DOS+temp;
                temp=" -M ";
                EIG2DOS=EIG2DOS+temp;
                cout << "Enter Emax (eV) : ";
                cin >> temp;
                EIG2DOS=EIG2DOS+temp;
                EIG2DOS=EIG2DOS+space;
                EIG2DOS=EIG2DOS+EIGFile;
                temp=" > ";
                EIG2DOS=EIG2DOS+temp;

                string output="EIG2DOS.out";
                output=WorkDir+output;
                EIG2DOS=EIG2DOS+output;

                cout << "EIG2DOS is computing ..." << endl;
                FILE *in;
                char buff[512];
                if(!(in = popen(EIG2DOS.c_str(), "r"))){
                        return 1;
                }
                while(fgets(buff, sizeof(buff), in)!=NULL){
                        cout << buff;
                }
                cout << "EIG2DOS has finished !" << endl;


                vector<string> DataFile;
                mat DATA(N,4);
                ifstream ReadDOS(output.c_str());
                assert(ReadDOS.is_open());
                int i=0;
                int j=0;
                char c;
                while(!ReadDOS.eof())
                {
                    getline(ReadDOS,temp);
                    if(temp[0]=='#')
                    {
                        DataFile.push_back(temp);
                        i++;
                    }
                    else
                    {

                        istringstream StrStream(temp);
                        StrStream >> DATA(j,0) >> DATA(j,1) >> DATA(j,2) >> DATA(j,3) ;
                        j++;
                    }
                    if(j==N) break;
                }
                ReadDOS.close();

                string GP="DOS.gp";
                GP=WorkDir+GP;

                ofstream WriteGP(GP.c_str());
                assert(WriteGP.is_open());
                WriteGP << "# \t E \t N(up) \t -N(down) \t Ntot \t SpinPol" << endl;
                double a;
                for(int i=0; i<DATA.n_rows; i++)
                {
                    WriteGP << DATA(i,0) << " ";
                    WriteGP << DATA(i,1) << " ";
                    WriteGP << -DATA(i,2) << " ";
                    WriteGP << DATA(i,3) << " ";
                    if(DATA(i,3)==0) a=0;
                    else a = 100*(DATA(i,1)-DATA(i,2))/DATA(i,3);
                    WriteGP << a << endl;
                }
                WriteGP.close();











                break;
            }case 8:
            {
                cout << endl;
                cout << "------------------------------" << endl;
                cout << "--------STICK--------" << endl;
                cout << "------------------------------" << endl;
                cout << endl;

                string LeftXV,RightXV;
                cout <<"Select the .XV file of the LEFT part" << endl;
                SelectFile(LeftXV,"Select the .XV file of the LEFT part","XV");
                cout <<"Select the .XV file of the RIGHT part" << endl;
                SelectFile(RightXV,"Select the .XV file of the RIGHT part","XV");
                mat AtomPosLeft,LatVecLeft,AtomPosRight,LatVecRight;
                ReadXVFile(LatVecLeft,AtomPosLeft,LeftXV);
                ReadXVFile(LatVecRight,AtomPosRight,RightXV);

                double d=LatVecLeft(2,2);
                cout << d << endl;

                int N=AtomPosLeft.n_rows+AtomPosRight.n_rows;
                mat AtomPosTotal(N,4);
                cout << N << endl;
                for(int i=0; i< AtomPosLeft.n_rows;i++)
                {
                    for(int j=0; j<4; j++)
                    {

                        AtomPosTotal(i,j)=AtomPosLeft(i,j);
                    }
                }
                for(int i=AtomPosLeft.n_rows; i<N; i++)
                {
                    for(int j=0; j<4; j++)
                    {
                        if(j==2)
                        {
                            AtomPosTotal(i,j)=AtomPosRight(i-AtomPosLeft.n_rows,j)+d;
                        }
                        else
                        {
                            AtomPosTotal(i,j)=AtomPosRight(i-AtomPosLeft.n_rows,j);
                        }

                    }
                }

                mat LatVecTotal(3,3);
                for(int i=0; i<3; i++)
                {
                    for(int j=0; j<3; j++)
                    {
                        if(i==2 && j==2)
                        {
                            LatVecTotal(i,j)=LatVecLeft(i,j)+LatVecRight(i,j);
                        }
                        else
                        {
                            LatVecTotal(i,j)=LatVecLeft(i,j);
                        }
                    }
                }

                for(int i=0; i<AtomPosTotal.n_rows; i++)
                {
                    for(int j=0; j<AtomPosTotal.n_cols; j++)

                        if(abs(AtomPosTotal(i,j))<0.000001) AtomPosTotal(i,j)=0;
                }

                string WorkDir;
                SelectDirectory(WorkDir,"Select destination directory.");
                string temp="/PASTED.XV";
                temp=WorkDir+temp;
                WriteXVFile(AtomPosTotal,LatVecTotal,temp);
                temp="/StructureDefinition.fdf";
                temp=WorkDir+temp;
                GenerateFDFstructure(AtomPosTotal,LatVecTotal,temp);
                break;
            }
        case 9:
            {
                MullikenVisualization();
                break;
            }
        case 10:
            {
                TransiestaRunPreparation();
                break;
            }
        case 11:
            {
                SpinPolarizationAtTheEdge();
                break;
            }
        case 12:
            {
                DencharPreparation();
                break;
            }
        case 13:
            {
                LandauerButtikerFormalism();
                break;
            }
        case 14:
            {
                CurrentFromTransmission();
                break;
            }



        default: std::cout << "default\n"; // no error
                 break;
        }
    cout << "\nRun is over ! " <<endl;
    cout << "Do you want to exit the program ? Enter 0 to make a new run..." <<endl;
    cout << "Choice : " ;
    cin >> Choice;
    cout << "\n\n" << endl;
    if(Choice==0)
        {
            Again=true;
        }
    }while(Again==true);








    now = time(0);
    localtm = localtime(&now);
    cout << "\nEnd of run : " << asctime(localtm) << endl;


    return 0;
}










void ReadTransFile(mat &Data, string File)
{
    ifstream Read(File.c_str());
    assert(Read.is_open());
    vector<double> k,Trans,TotDOS,PDOS;
    string temp;
    getline(Read,temp);
    getline(Read,temp);
    getline(Read,temp);
    getline(Read,temp);
    double a;

    while(!Read.eof())
    {
        Read >> a;
        k.push_back(a);
        Read >> a;
        Trans.push_back(a);
        Read >> a;
        TotDOS.push_back(a);
        Read >> a;
        PDOS.push_back(a);
    }
    Read.close();

    int N=k.size();
    cout << N << endl;
    if(k[N-1]==Trans[N-1] && k[N-1]==PDOS[N-1])
    {
        k.pop_back();
        Trans.pop_back();
        TotDOS.pop_back();
        PDOS.pop_back();
    }
    N=k.size();
    cout << N << endl;
    Data.zeros(N,4);
    for (int i=0; i<N; i++)
    {
        Data(i,0)=k[i];
        Data(i,1)=Trans[i];
        Data(i,2)=TotDOS[i];
        Data(i,3)=PDOS[i];
    }

    return;
}





