#ifndef MULLIKENVISUALIZATION_H
#define MULLIKENVISUALIZATION_H
using namespace std;

void MullikenVisualization();

#endif // MULLIKENVISUALIZATION_H

