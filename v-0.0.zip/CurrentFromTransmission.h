#ifndef CURRENTFROMTRANSMISSION_H
#define CURRENTFROMTRANSMISSION_H
using namespace std;
using namespace arma;

void CurrentFromTransmission();
double SimpleIntegral(vector<double>& x, vector<double>& y, double x0, double xN);

#endif // CURRENTFROMTRANSMISSION_H

