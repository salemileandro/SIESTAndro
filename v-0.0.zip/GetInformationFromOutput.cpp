#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <iomanip>
#include <vector>
#include <armadillo>
#include"StringFunctions.h"
using namespace std;
using namespace arma;

void GetSystemLabel(string OutputFile, string &SystemLabel)
{
    ifstream ReadFile(OutputFile.c_str());
    assert(ReadFile.is_open());
    string target,temp;
    target="SystemLabel";
    while(!ReadFile.eof())
    {
        getline(ReadFile,temp);
        if(ContainString(temp,target))
        {
            istringstream StrStream(temp);
            StrStream >> SystemLabel;
            StrStream >> SystemLabel;
        }
    }

    ReadFile.close();
    return;
}


void GetKGrid(string OutputFile, vec &KGrid)
{
    ifstream ReadFile(OutputFile.c_str());
    assert(ReadFile.is_open());
    string target,temp;
    target="kgrid_Monkhorst_Pack";
    double a;
    while(!ReadFile.eof())
    {
        getline(ReadFile,temp);
        if(ContainString(temp,target))
        {
            getline(ReadFile,temp);
            istringstream StrStream(temp);
            StrStream >> KGrid(0) >> a >> a >>a ;

            getline(ReadFile,temp);
            istringstream StrStream1(temp);
            StrStream1 >> a >> KGrid(1) >> a >>a ;

            getline(ReadFile,temp);
            istringstream StrStream2(temp);
            StrStream2 >> a >> a >> KGrid(2) >>a ;

            break;
        }
    }

    ReadFile.close();
    return;

}

double GetMeshCutOff(string OutputFile)
{
    ifstream ReadFile(OutputFile.c_str());
    assert(ReadFile.is_open());
    string target,temp;
    target="MeshCutoff";
    double a;
    while(!ReadFile.eof())
    {
        getline(ReadFile,temp);
        if(ContainString(temp,target))
        {
            istringstream StrStream(temp);
            StrStream >> target;
            StrStream >> a;
        }
    }
    ReadFile.close();
    return a;

}




void GetBondLength(mat AtomicCoordinates,mat BondInput,vec &BondLength)
{
    vec temp1(3),temp2(3);
    for(int i=0; i<BondInput.n_rows; i++)
    {
        for(int j=0; j<BondInput.n_cols; j++)
        {
            BondInput(i,j)=BondInput(i,j)-1;
        }
    }
    BondLength.zeros(BondInput.n_rows);

    for(int i=0; i<BondInput.n_rows; i++)
    {
        temp1=(AtomicCoordinates.row(BondInput(i,0))).t();
        temp2=(AtomicCoordinates.row(BondInput(i,1))).t();
        temp1=temp1-temp2;
        BondLength(i)=norm(temp1);
    }

    return;


}

int GetNumberAtoms(string OutputFile)
{
    ifstream ReadFile(OutputFile.c_str());
    assert(ReadFile.is_open());
    string target,temp;
    target="NumberOfAtoms";
    int a;
    while(!ReadFile.eof())
    {
        getline(ReadFile,temp);
        if(ContainString(temp,target))
        {
            istringstream StrStream(temp);
            StrStream >> target;
            StrStream >> a;
        }
    }
    ReadFile.close();
    return a;
}

void ReadXVFile(mat &LatticeVectors, mat &AtomicPositions, string FileName)
{
    // Read the lattice vectors and atomic positions
    // from the .XV file.
    // Physical values are in ANGSTROM !

    ifstream ReadFile(FileName.c_str());
    assert(ReadFile.is_open());
    LatticeVectors.zeros(3,3);
    double a=0.529177249;
    double dummy;
    int Natoms;

    for(int i=0; i<3; i++)
    {
        ReadFile >> LatticeVectors(i,0);
        ReadFile >> LatticeVectors(i,1);
        ReadFile >> LatticeVectors(i,2);
        ReadFile >> dummy;
        ReadFile >> dummy;
        ReadFile >> dummy;
    }
    ReadFile >> Natoms;
    AtomicPositions.zeros(Natoms,4);
    for(int i=0; i<Natoms; i++)
    {
        ReadFile >> AtomicPositions(i,3);
        ReadFile >> dummy;
        ReadFile >> AtomicPositions(i,0);
        ReadFile >> AtomicPositions(i,1);
        ReadFile >> AtomicPositions(i,2);
        ReadFile >> dummy;
        ReadFile >> dummy;
        ReadFile >> dummy;
    }
    ReadFile.close();

    for(int i=0; i<AtomicPositions.n_rows; i++)
    {
        for (int j=0; j<(AtomicPositions.n_cols-1); j++)
        {
            AtomicPositions(i,j)=AtomicPositions(i,j)*a;
        }
    }

    for(int i=0; i<LatticeVectors.n_rows; i++)
    {
        for (int j=0; j<LatticeVectors.n_cols; j++)
        {
            LatticeVectors(i,j)=LatticeVectors(i,j)*a;
        }
    }


    return;

}

void WriteXVFile(mat AtomicPositions, mat LatticeVectors ,string OutputFile)
{
    double a=0.529177249;
    a=1.0/a;

    for(int i=0; i<AtomicPositions.n_rows; i++)
    {
        for (int j=0; j<(AtomicPositions.n_cols-1); j++)
        {
            AtomicPositions(i,j)=AtomicPositions(i,j)*a;
        }
    }

    for(int i=0; i<LatticeVectors.n_rows; i++)
    {
        for (int j=0; j<LatticeVectors.n_cols; j++)
        {
            LatticeVectors(i,j)=LatticeVectors(i,j)*a;
        }
    }


    for(int i=0; i<AtomicPositions.n_rows; i++)
    {
        for(int j=0; j<AtomicPositions.n_cols; j++)
        {
            if(abs(AtomicPositions(i,j))<0.00001) AtomicPositions(i,j)=0;
            if(AtomicPositions(i,j)==-0.0) AtomicPositions(i,j)=0;
        }
    }
    ofstream Write(OutputFile.c_str());
    assert(Write.is_open());
    Write << setprecision (9) << fixed;
    for(int i=0; i<3; i++)
    {
        Write << "\t" << LatticeVectors(i,0) << "\t"<< LatticeVectors(i,1) << "\t"<< LatticeVectors(i,2) << "\t";
        Write <<  0.0 << "\t" << 0.0 << "\t" << 0.0 << endl;
    }
    Write << "\t" << AtomicPositions.n_rows << endl;
    for(int i=0; i<AtomicPositions.n_rows; i++)
    {
        Write << "  "<<(int(AtomicPositions(i,3))) << "\t";
        if((int(AtomicPositions(i,3)))==2)
        {
            Write << (int(1)) << "\t";
        }
        if((int(AtomicPositions(i,3)))==1)
        {
            Write << (int(6)) << "\t";
        }
        Write << AtomicPositions(i,0) << "\t"<< AtomicPositions(i,1) << "\t";
        Write << AtomicPositions(i,2) << "\t";
        Write << 0.0 << "\t" << 0.0 << "\t" << 0.0 << endl;
    }
    Write.close();
    return;
}

void GenerateFDFstructure(mat AtomicPositions,mat LatticeVectors, string FDFfile)
{
    double b=1;
    ofstream Write(FDFfile.c_str());
    assert(Write.is_open());
    Write << setprecision (9) << fixed;
    Write << "NumberOfAtoms	"<< AtomicPositions.n_rows << endl;
    Write << "NumberOfSpecies     2" << endl;
    Write << "%block ChemicalSpeciesLabel" << endl;
    Write << "1 6   C" << endl;
    Write << "2 1   H" << endl;
    Write << "%endblock ChemicalSpeciesLabel" << endl;
    Write << "LatticeConstant     1.00    Ang" << endl;
    Write << "%block LatticeVectors" << endl;
    for(int i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            Write << LatticeVectors(i,j)*b << "  " ;
        }
        Write << endl;
    }
    Write << "%endblock LatticeVectors" << endl;
    Write << "AtomicCoordinatesFormat     Ang" << endl;
    Write << "%block AtomicCoordinatesAndAtomicSpecies" << endl;
    for(int i=0; i<AtomicPositions.n_rows; i++)
    {
        if(abs(AtomicPositions(i,0))<0.00000001)AtomicPositions(i,0)=0;
        if(abs(AtomicPositions(i,1))<0.00000001)AtomicPositions(i,1)=0;
        if(abs(AtomicPositions(i,2))<0.00000001)AtomicPositions(i,2)=0;
        Write << AtomicPositions(i,0)*b << " ";
        Write << AtomicPositions(i,1)*b << " ";
        Write << AtomicPositions(i,2)*b << " ";
        Write << (int(AtomicPositions(i,3))) << endl;
    }
    Write <<"%endblock AtomicCoordinatesAndAtomicSpecies" << endl;

    Write.close();
    return;
}
