#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <string.h>
#include <sstream>
#include <iomanip>
#include <vector>
#include <armadillo>
#include"StringFunctions.h"
#include"FileBrowser.h"
#include"CurrentFromTransmission.h"
using namespace std;
using namespace arma;

void CurrentFromTransmission()
{
    cout << endl;
    cout << "-------------------------------" << endl;
    cout << "---Current From Transmission---" << endl;
    cout << "-------------------------------" << endl;
    cout << endl;


    string TransFileUP,TransFileDN,WorkDir;
    SelectFile(TransFileUP,"Select the SPIN UP .TRANS file of your system","TRANS");
    SelectFile(TransFileDN,"Select the SPIN DOWN .TRANS file of your system","TRANS");
    GetDirectory(WorkDir,TransFileUP);
    ifstream ReadFileup(TransFileUP.c_str());
    assert(ReadFileup.is_open());
    string temp;
    vector<double> E;
    E.clear();
    vector<double> Tup;
    Tup.clear();
    double a,b;
    while(getline(ReadFileup,temp))
    {
        if(temp[0]!='#' && temp.size()>2)
        {
            stringstream ss;
            ss.str(temp);
            ss >> a >> b;
            if(abs(b)<0.0001)
                b=0;
            E.push_back(a);
            Tup.push_back(b);
        }
    }
    ReadFileup.close();
    vector<double> Iup(E.size());
    for(int i=0; i<E.size(); i++)
    {
        a=SimpleIntegral(E,Tup,0.0,E[i]);
        Iup[i]=a;
    }


    ifstream ReadFiledn(TransFileDN.c_str());
    assert(ReadFiledn.is_open());
    vector<double> Tdn;
    Tdn.clear();
    E.clear();
    while(getline(ReadFiledn,temp))
    {
        if(temp[0]!='#' && temp.size()>2)
        {
            stringstream ss;
            ss.str(temp);
            ss >> a >> b;
            if(abs(b)<0.0001)
                b=0;
            E.push_back(a);
            Tdn.push_back(b);
        }
    }
    ReadFiledn.close();
    vector<double> Idn(E.size());
    for(int i=0; i<E.size(); i++)
    {
        a=SimpleIntegral(E,Tdn,0.0,E[i]);
        Idn[i]=a;
    }

    string CurrentFile="/Current.gp";
    CurrentFile=WorkDir+CurrentFile;
    ofstream WriteCurrent(CurrentFile.c_str());
    assert(WriteCurrent.is_open());
    for(int i=0; i<E.size(); i++)
    {
        if((Iup[i]+Idn[i])!=0)
        {
            a=(Iup[i]-Idn[i])/(Iup[i]+Idn[i]);
            WriteCurrent << E[i] << " " << Iup[i] << " " << Idn[i] << " " << a << endl;
        }
        else
        {
            WriteCurrent << E[i] << " " << Iup[i] << " " << Idn[i] << " " << 0.0 << endl;
        }
    }
    WriteCurrent.close();

    string CurrentPolFile="/CurrentPolarization.gp";
    CurrentPolFile=WorkDir+CurrentPolFile;
    ofstream WriteCurrentPol(CurrentPolFile.c_str());
    assert(WriteCurrentPol.is_open());
    double test;
    for(int i=0; i<E.size(); i++)
    {
        test=1;
        if(i<(E.size()-1))
            test=E[i]*E[i+1];
        if((Iup[i]+Idn[i])!=0)
        {
            a=(Iup[i]-Idn[i])/(Iup[i]+Idn[i]);
            WriteCurrentPol << E[i] << " " << a << endl;
        }
        if( Iup[i]==0 && Idn[i]==0 && test>0)
        {
            WriteCurrentPol << E[i] << " " << 0 << endl;
        }

    }
    WriteCurrentPol.close();
}

double SimpleIntegral(vector<double>& x, vector<double>& y, double x0, double xN)
{
    double Sum=0;
    int N=x.size();
    double a,b;
    double SIGN=1;
    if(x0>xN)
    {
        a=x0;
        x0=xN;
        xN=a;
        SIGN=-1;
    }
    for(int i=0; i<N; i++)
    {
        if((x[i]>x0 && x[i]<xN))
        {
            a=x[i+1]-x[i];
            b=y[i];
            Sum=Sum+a*b;
        }
    }
    return (SIGN*Sum);
}

