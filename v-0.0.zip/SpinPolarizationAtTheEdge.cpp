#include<string>
#include <stdio.h>
#include <fstream>
#include <cassert>
#include <stdlib.h>
#include <armadillo>
#include <iomanip>
#include <vector>
#include"StringFunctions.h"
#include"GetInformationFromOutput.h"
#include"FileBrowser.h"

using namespace std;
using namespace arma;

void SpinPolarizationAtTheEdge()
{
    cout << endl;
    cout << "-----------------------------------" << endl;
    cout << "---Spin Polarization At the Edge---" << endl;
    cout << "-----------------------------------" << endl;
    cout << endl;

    cout << "X-direction : Normal" << endl;
    cout << "Y-direction : Transversal" << endl;
    cout << "Z-direction : Longitudinal (PERIODIC)" << endl;
    cout << endl;

    string FileXV,WorkDir;
    SelectFile(FileXV,"Select the .XV file of your system !","XV");
    mat AtomPos,LatVec;
    ReadXVFile(LatVec,AtomPos,FileXV);
    GetDirectory(WorkDir,FileXV);

    char Spin;
    double Y;
    cout << "Give the spin (+ or -) : ";
    cin >> Spin;
    cout << "Give the transversal coordinate y (ANGSTROM): ";
    cin >> Y;

    string temp="/SpinPolarization.txt";
    temp=WorkDir+temp;
    ofstream WriteSpin(temp.c_str());
    assert(WriteSpin.is_open());
    WriteSpin << "SpinPolarized         .true." << endl;
    WriteSpin << "%block DM.InitSpin" << endl;
    for(int i=0; i<AtomPos.n_rows; i++)
    {
        if(abs(AtomPos(i,1)-Y)<0.5)
            WriteSpin << i+1 << " " << Spin << endl;
    }

    cout << "Give the spin (+ or -) : ";
    cin >> Spin;
    cout << "Give the transversal coordinate y (ANGSTROM): ";
    cin >> Y;
    for(int i=0; i<AtomPos.n_rows; i++)
    {
        if(abs(AtomPos(i,1)-Y)<0.5)
            WriteSpin << i+1 << " " << Spin << endl;
    }
    WriteSpin << "%endblock DM.InitSpin";
    WriteSpin.close();





}
