#ifndef FILEBROWSER_H
#define FILEBROWER_H
using namespace std;

void SelectFile(string &Filename, string message,string FileType);
void GetDirectory(string &Directory, string File);
void SelectDirectory(string &DirectoryName, string message);


#endif // FILEBROWSER_H
